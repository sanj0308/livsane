//[Master Javascript]

//Project:	Zoom - Multipage Html Responsive Template
//Version:	1.1
//Last change:	01/09/2017
//Primary use:	Zoom - Multipage Html Responsive Template 


//Template script here

$(document).ready(function(){
    "use strict"; // Start of use strict
	
	
	
	// Master slider Home page
	
	var slider = new MasterSlider();	 
		  
		slider.control('bullets'); 
	 
		slider.setup('masterslider' , {
			width:1024,
			height:768,
			space:5,
			view:'fade',
			layout:'fullscreen',
			speed:20,
			overPause:false,
			autoplay:true
		});
	
	
	// Team slider Home page
	
	var owl = $('.owl-carousel');
		owl.owlCarousel({
			items:2,
			loop:true,
			margin:0,
			autoplay:true,
			autoplayTimeout:5000,
			autoplayHoverPause:true
		});
		$('.play').on('click',function(){
			owl.trigger('play.owl.autoplay',[5000])
		})
		$('.stop').on('click',function(){
			owl.trigger('stop.owl.autoplay')
		})
		
		
	// Chart
		
		var pieData = [
				{
					value: 30,
					color:"#F38630"
				},
				{
					value : 50,
					color : "#E0E4CC"
				},
				{
					value : 100,
					color : "#69D2E7"
				},
				{
					value : 45,
					color : "#1E73BE"
				}

			];
		var myPie = new Chart(document.getElementById("dart-pie-chart").getContext("2d")).Pie(pieData);
	
	// Counter
	
	$('.count').each(function () {
		$(this).prop('Counter',0).animate({
			Counter: $(this).text()
		}, {
			duration: 4000,
			easing: 'swing',
			step: function (now) {
				$(this).text(Math.ceil(now));
			}
		});
	});


	// Gallery prettyPhoto

	  $(document).ready(function($){
		$("a[rel^='alternate']").prettyPhoto();
	  });



}); // End of use strict



