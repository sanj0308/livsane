//[Custom Javascript]

//Project:	Zoom - Onepage Html Responsive Template
//Version:	1.1
//Primary use:	Zoom - Onepage Html Responsive Template 

//add your script here

